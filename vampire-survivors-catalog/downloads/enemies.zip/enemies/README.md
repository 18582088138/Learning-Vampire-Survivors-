# enemies

怪物首帧 Sprite、基础生命/速度/Power/XP、技能、抗性与图鉴变体数据。

## 内容

- images: 579
- bestiaryIncluded: 180

## 使用方式

图片位于 images/，数值位于 data/。manifest.json 记录文件大小、SHA-256、覆盖率和来源。

## 来源与许可

游戏数据与 Sprite 提取自用户本地安装的 Vampire Survivors，仅供学习、研究与二次分析。相关游戏内容权利归原作者及发行方。图片由 Unity Sprite 导出，未进行重绘。本包不包含游戏可执行文件、完整原始资源包或音频。
