# research

结构化数据、CSV 与架构/机制/地图研究报告，便于代码分析和二次整理。

## 内容

- jsonFiles: 5
- csvFiles: 8
- researchDocuments: 5

## 使用方式

图片位于 images/，数值位于 data/。manifest.json 记录文件大小、SHA-256、覆盖率和来源。

## 来源与许可

游戏数据与 Sprite 提取自用户本地安装的 Vampire Survivors，仅供学习、研究与二次分析。相关游戏内容权利归原作者及发行方。图片由 Unity Sprite 导出，未进行重绘。本包不包含游戏可执行文件、完整原始资源包或音频。
